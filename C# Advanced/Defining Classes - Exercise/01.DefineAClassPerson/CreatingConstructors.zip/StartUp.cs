﻿namespace DefiningClasses;

public class StartUp
{
    static void Main(string[] args)
    {
        Person person1 = new Person();
        person1.Name = "Peter";
        person1.Age = 20;

        Console.WriteLine($"{person1.Name} is {person1.Age} years old");

        Person person2 = new Person
        {
            Name = "Gosho",
            Age = 18
        };

        Console.WriteLine($"{person2.Name} is {person2.Age} years old");

        Person person3 = new Person
        {
            Name = "Jose"
        };
        person3.Age = 43;

        Console.WriteLine($"{person3.Name} is {person3.Age} years old");
    }
}
